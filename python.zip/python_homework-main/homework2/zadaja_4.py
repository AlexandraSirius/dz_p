category=input('Категория:')
if category == 'Продукты':
