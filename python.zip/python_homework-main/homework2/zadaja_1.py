food=input()
if food == 'Завтрак':
    print('Каша')
elif food == 'Обед':
    print('Плов')
else:
    print('Котлета с пюре')