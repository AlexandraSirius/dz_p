var=['gosha','dan','artem']
print(' ', .join(var))