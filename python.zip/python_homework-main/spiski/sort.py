numbers=[1,5,2,4,3]
numbers.sort()
print(numbers)