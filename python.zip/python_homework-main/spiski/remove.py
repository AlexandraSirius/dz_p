var=['gosha', 'dan', 'artem']
var.remove('gosha')
print(var)