numbers = [1,5,9,6]
numbers.extend([2,3])#может добавлять списки
print(numbers)