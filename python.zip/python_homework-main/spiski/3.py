var = [1,2,3,4]
var2=0
for i in var:
    var2+=i
print(var2)