var=['gosha', 'dan', 'artem']
var.pop(1)
print(var)