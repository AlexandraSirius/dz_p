numbers=[1,2,3,4,5,6,1,3,1,7,8,1]
print(numbers.count(1))