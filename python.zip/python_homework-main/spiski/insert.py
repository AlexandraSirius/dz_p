numbers=[1,5,9,6]
numbers.insert(3,[2,3])
print(numbers)