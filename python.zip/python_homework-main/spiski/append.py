var=['Кирилл', 'Даня']
var.append('Олег')
print(var)