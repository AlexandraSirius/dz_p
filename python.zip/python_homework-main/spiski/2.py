var = [ 'Кирилл', 'Марьям', 'Артём',12,True,1.5]
var2 =['Олег']
var3 = var + var2
print(var3)