a=(input())
b=(input())
for x in range(a,b+1):
    print(float(len(x)))