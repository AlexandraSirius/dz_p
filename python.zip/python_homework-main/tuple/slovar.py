base_of_students={"name":"georgi","age":17}
base_of_students["marks"]=[1,2,3,4,5]
print(base_of_students)