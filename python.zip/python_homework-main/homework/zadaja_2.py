a=int(input())
b=('r')
print(a*b)