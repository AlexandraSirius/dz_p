n=input()
a, b= n.split(' ')
print(b,a)