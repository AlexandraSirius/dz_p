a=('abc')
b=('def')
print(a+b)
