a=input()
print(str(a[2:,:6]))