a='mylogin@yandex.ru'
print(a[:7])