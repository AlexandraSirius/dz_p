numbers=[5,4,3,2]
print(numbers)
print((numbers.count{5}+numbers.count{4}+numbers.count{3})/(len(numbers))*100)