numbers = input().split()
k=numbers.count('5')
print(k/len(numbers)*100)