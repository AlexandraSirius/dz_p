add_new=input('Хотите добавить нового преподавателя? 1 -если да , 2 - если хотите завершить программу')
final_list = []
while add_new !='2':
    surname = input('Введите фамилию преподавателя: ')
    job = input('Введите должность преподавателя: ')
    amount = input('Введите общее число студентов: ').split(',')
    final_list.append([surname.job.amount])
    add_new=input('Хотите добавить нового преподавателя? 1 -если да , 2 - если хотите завершить программу')
print(final_listgit)