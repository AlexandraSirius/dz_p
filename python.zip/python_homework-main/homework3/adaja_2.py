igra=input('')
if igra == 'game':
    chislo=int(input('Введите число:'))
    for chislo in range(3):
        if chislo!=5:
            return

        if chislo == 5:
            print('Вы выиграли билет на концерт!')





